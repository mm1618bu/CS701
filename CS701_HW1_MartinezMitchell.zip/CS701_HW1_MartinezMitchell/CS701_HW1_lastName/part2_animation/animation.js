// Mitchell Martinez - CS701
var animModule = (function() {

    window.onload = init;

    var canvas;
    var context;
    var width, height;

    var ballRadius = 10;
    var ballColor = "blue";
    var ballPosition;
    var points = [];

    // displacement of ball for each step
    var dx = 5;
    var dy = 25;

    var currentRow = 0;
    var currentDirection = 1;

    function init() {

        canvas = document.getElementById('testCanvas');
        context = canvas.getContext('2d');

        width = canvas.width;
        height = canvas.height;

        // current ball position
        ballPosition = {x : ballRadius, y : ballRadius};
    }

    function updatePosition() {
        if (currentDirection == 1) {
            dx = 5;
        } else {
            dx = -5;
        }
    };

    function setSpeed(speed) {
        dx = (currentDirection == 1) ? speed / 10 : -speed / 10;
    }

    // draw current position on the canvas
    function drawBallOnCanvas() {
        var fillStyle;
        // Clear the canvas
        context.fillStyle = '#D3C0C0';
        context.fillRect(0, 0, canvas.width, canvas.height);

        context.strokeStyle = '#000000';
        context.strokeRect(1, 1, canvas.width - 2, canvas.height - 2);

        if (points.length == 2000) {
            points.splice(0, points.length);
        }

        ballPosition.x += dx;

        if (currentRow % 2 == 0) { // if the current row number is even, make the ball red
            context.fillStyle = "#FF0000";
        } else { // otherwise, make the ball blue
            context.fillStyle = "#0000FF";
        }

        context.beginPath();
        context.arc(ballPosition.x, ballPosition.y, ballRadius, 0, Math.PI * 2);
        context.fill();
        context.closePath();

        points.push({ x: ballPosition.x, y: ballPosition.y });

        if (ballPosition.x + ballRadius > canvas.width) {
            currentDirection = -1;
            ballPosition.x = canvas.width - ballRadius;
            ballPosition.y += ballRadius * 2; // move down to the next row
            currentRow++; // increment the row number
            updatePosition();
        } else if (ballPosition.x - ballRadius < 0) {
            currentDirection = 1;
            ballPosition.x = ballRadius;
            ballPosition.y += ballRadius * 2; // move down to the next row
            currentRow++; // increment the row number
            updatePosition();
        }

        if (ballPosition.y + ballRadius > canvas.height) {
            // stop the animation
            return;
        }
    }

    // browser specific animation request
     window.requestAnimFrame = (function(){
          return  window.requestAnimationFrame       ||
                  window.webkitRequestAnimationFrame ||
                  window.mozRequestAnimationFrame    ||
                  window.oRequestAnimationFrame      ||
                  window.msRequestAnimationFrame     ||
                  // fall back to JavaScript setTimeout
                  function(callback, element){
                    window.setTimeout(callback, 1000 / 60);
                  };
        })();
            
        // Define the Animation
        function doAnimation() {
            // Draw a single frame of animation on our canvas
            drawBallOnCanvas();

            // After this frame is drawn, let the browser schedule the next one

            window.requestAnimFrame(doAnimation);
        }

        // Start the Animation
            
         window.requestAnimFrame(doAnimation);

         return {
            setSpeed: setSpeed
         }
    

})();












