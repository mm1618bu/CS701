// Mitchell Martinez CS701

var bullsEyeModule = (function() {

    window.onload = init;

    var canvas;
    var context;

    var centerX, centerY;

    var delay = false;

    var timerId;

    var radius;
    var numRings;
    function init() {
        
            canvas = document.getElementById("testCanvas");
            context = canvas.getContext("2d");

            centerX = canvas.width / 2;
            centerY = canvas.height / 2;
            radius = canvas.width / 2 - 10;
            drawPattern();
    }


    function drawPattern() {
        if (timerId) {
          clearInterval(timerId);
          timerId = undefined;
        }
      
        context.clearRect(0, 0, canvas.width, canvas.height);
      
        var bandWidth = document.getElementById("band").value;
        document.getElementById("widthDisplay").value = bandWidth;
      
        delay = document.getElementById("delay").checked;
      

        numRings = Math.ceil(radius / bandWidth);
      

        for (var i = 0; i < numRings; i++) {
          var color = i % 2 === 0 ? "#FF0000" : "#0000FF";
          var ringRadius = radius - (i * bandWidth);
          var gradient = context.createRadialGradient(
            centerX,
            centerY,
            ringRadius,
            centerX,
            centerY,
            0
          );
          gradient.addColorStop(0, color);
          gradient.addColorStop(1, color);
          context.fillStyle = gradient;
          context.beginPath();
          context.arc(centerX, centerY, ringRadius, 0, 2 * Math.PI);
          context.fill();
          context.closePath();
        }
      }



    return {
        drawPattern: drawPattern
    };

})();






