// Mitchell Martinez CS701
var rotationsModule = (function() {


	function changeSpeed() {
		var duration = document.getElementById("duration").value;
		document.getElementById("durationDisplay").textContent = duration + 's';
	
		var animations = document.querySelectorAll("animateTransform");
	
		for (var i = 0; i < animations.length; i++) {
			animations[i].setAttribute("dur", duration + "s");
		}
	}

	return {
        changeSpeed: changeSpeed
    };

})();